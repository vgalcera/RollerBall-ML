﻿using MLAgents;

public class RollerAcademy : Academy {


}
